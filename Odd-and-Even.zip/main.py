#number data types
import random

# subroutine to return odd or even
def OddEven(Number):
  if Number % 2 == 1:
    return "Odd"
  else:
    return "Even"

#Main Program
print(OddEven(8))
print(OddEven(7))
print(OddEven(0))
print(OddEven(-1))
print(OddEven(-6))