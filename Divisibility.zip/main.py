#taking inputs
no1 = int(input("Enter the first number: "))
no2 = int(input("Enter the second number: "))

#decides whether the numbers are divisible
if no2 == 0:
  statement = False
elif no1 % no2 == 0:
  statement = True
else:
  statement = False

#prints whether its divisible or not
print(statement)