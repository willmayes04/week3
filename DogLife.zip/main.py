#Program that calculates a dogs age in human years

#Function that converts the age and returns a value
def DogLife(DogAge):
  if DogAge <= 2:
    RealAge = DogAge * 12
  elif DogAge > 2:
    RealAge = 24 + ((DogAge - 2) * 6)
  return RealAge

#takes the inputs
DogAge = float(input("Enter dog's age: "))

#runs the function
DogLife(DogAge)

#outputs the returned value from the function
RealAge = DogLife(DogAge)
print("Dog's age in human years is:",int(RealAge))