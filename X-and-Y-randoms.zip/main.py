# number data types
import random

# subroutine to deomstarte casting and operators
def MathsDemo(X,Y):
  DivisionResult = X / Y
  print("{} divided by {} is {}".format(X, Y, DivisionResult))
  IntDivisonResult = X // Y
  print("")