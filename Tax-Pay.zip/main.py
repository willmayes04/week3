#number data types

#subroutine to calculate VAT
def VAT(Total):
  return Total * 0.2

#Main
Total = 99.99
ValueAddedTax = VAT(Total)
ToPay = Total + ValueAddedTax
print("Total £{:.2f} VAT £{:.2f} To pay £{:.2f}".format(Total, ValueAddedTax , ToPay))