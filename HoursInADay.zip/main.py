#program that takes a number of hours and returns how many days that would be

#take inputs
hours = int(input("Enter the hours: "))

#calculates the number of days
days = hours / 24

#outputs result
print(int(days))