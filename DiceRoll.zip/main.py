#Random data types
import random

#Subroutine to generate a random number
def DiceRoll():
  return random.randint(1,12)

#Main program
random.seed(20)
Dice = DiceRoll()
print("Rolled a {}".format(Dice))