#program that gets 3 dice rolls and outputs a score based on their number

#imports the random generator
import random

#calculates the score using its set methods
def DiceScore(Dice1,Dice2,Dice3):
  if Dice1 == Dice2 == Dice3:
    Score = Dice1 + Dice2 + Dice3
  else:
    if Dice1 == Dice2:
      Score = Dice1 + Dice2 - Dice3
    elif Dice2 == Dice3:
      Score = Dice2 + Dice3 - Dice1
    elif Dice3 == Dice1:
      Score = Dice3 + Dice1 - Dice2
    else:
      Score = 0
  return Score

#chooses random numbers and assigns them
Dice1 = random.randint(1,6)
Dice2 = random.randint(1,6)
Dice3 = random.randint(1,6)

#runs function and outputs result
DiceScore(Dice1,Dice2,Dice3)
Total = DiceScore(Dice1,Dice2,Dice3)
print(Total)